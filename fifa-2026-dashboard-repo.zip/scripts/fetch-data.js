#!/usr/bin/env node
/**
 * Fetches the latest World Cup 2026 data from the openfootball public-domain
 * dataset (no API key required) and writes it into data/standings.json in the
 * shape our dashboard expects.
 *
 * Source: https://github.com/openfootball/worldcup.json
 * Updated upstream ~once a day, so a daily GitHub Action keeps us in sync.
 */

const fs = require("fs");
const path = require("path");

const MATCHES_URL =
  "https://raw.githubusercontent.com/openfootball/worldcup.json/master/2026/worldcup.json";
const GROUPS_URL =
  "https://raw.githubusercontent.com/openfootball/worldcup.json/master/2026/worldcup.groups.json";

const FLAGS = {
  Mexico: "🇲🇽", "South Africa": "🇿🇦", "South Korea": "🇰🇷", Czechia: "🇨🇿",
  "Czech Republic": "🇨🇿", Canada: "🇨🇦", "Bosnia and Herzegovina": "🇧🇦",
  "Bosnia & Herzegovina": "🇧🇦", Qatar: "🇶🇦", Switzerland: "🇨🇭", Brazil: "🇧🇷",
  Morocco: "🇲🇦", Haiti: "🇭🇹", Scotland: "🏴󠁧󠁢󠁳󠁣󠁴󠁿", USA: "🇺🇸",
  "United States": "🇺🇸", Paraguay: "🇵🇾", Australia: "🇦🇺", Turkey: "🇹🇷",
  Türkiye: "🇹🇷", Germany: "🇩🇪", Curaçao: "🇨🇼", "Ivory Coast": "🇨🇮",
  "Côte d'Ivoire": "🇨🇮", Ecuador: "🇪🇨", Netherlands: "🇳🇱", Japan: "🇯🇵",
  Sweden: "🇸🇪", Tunisia: "🇹🇳", Belgium: "🇧🇪", Egypt: "🇪🇬", Iran: "🇮🇷",
  "New Zealand": "🇳🇿", Spain: "🇪🇸", "Cape Verde": "🇨🇻", "Cabo Verde": "🇨🇻",
  "Saudi Arabia": "🇸🇦", Uruguay: "🇺🇾", France: "🇫🇷", Senegal: "🇸🇳",
  Iraq: "🇮🇶", Norway: "🇳🇴", Argentina: "🇦🇷", Algeria: "🇩🇿", Austria: "🇦🇹",
  Jordan: "🇯🇴", Portugal: "🇵🇹", "DR Congo": "🇨🇩", "DRCongo": "🇨🇩",
  Uzbekistan: "🇺🇿", Colombia: "🇨🇴", England: "🏴󠁧󠁢󠁥󠁮󠁧󠁿", Croatia: "🇭🇷",
  Ghana: "🇬🇭", Panama: "🇵🇦",
};

const flagFor = (name) => FLAGS[name] || "🏳️";

function httpsGetJson(url, redirectsLeft = 5) {
  return new Promise((resolve, reject) => {
    const https = require("https");
    https
      .get(url, { headers: { "User-Agent": "fifa-dashboard-bot" } }, (res) => {
        if ([301, 302, 307, 308].includes(res.statusCode) && redirectsLeft > 0) {
          return resolve(httpsGetJson(res.headers.location, redirectsLeft - 1));
        }
        if (res.statusCode !== 200) {
          return reject(new Error(`HTTP ${res.statusCode} for ${url}`));
        }
        let body = "";
        res.on("data", (chunk) => (body += chunk));
        res.on("end", () => {
          try {
            resolve(JSON.parse(body));
          } catch (e) {
            reject(e);
          }
        });
      })
      .on("error", reject);
  });
}

/** Build the 12-group table (played/won/drawn/lost/gf/ga/pts) from match results. */
function buildGroups(rawGroups, matches) {
  const groupOf = {}; // teamName -> groupId
  const groups = rawGroups.map((g) => {
    const id = (g.name || "").replace(/^Group\s*/i, "").trim();
    const teamNames = g.teams || [];
    teamNames.forEach((t) => (groupOf[t] = id));
    return {
      id,
      teams: teamNames.map((name) => ({
        flag: flagFor(name),
        name,
        gp: 0, w: 0, d: 0, l: 0, gf: 0, ga: 0, pts: 0,
      })),
    };
  });

  const byId = Object.fromEntries(groups.map((g) => [g.id, g]));

  for (const m of matches) {
    if (!m.score || !m.score.ft) continue; // only count finished matches
    const [hg, ag] = m.score.ft;
    const gid = groupOf[m.team1] || groupOf[m.team2];
    if (!gid || !byId[gid]) continue;
    const grp = byId[gid];
    const home = grp.teams.find((t) => t.name === m.team1);
    const away = grp.teams.find((t) => t.name === m.team2);
    if (!home || !away) continue;

    home.gp++; away.gp++;
    home.gf += hg; home.ga += ag;
    away.gf += ag; away.ga += hg;
    if (hg > ag) { home.w++; home.pts += 3; away.l++; }
    else if (hg < ag) { away.w++; away.pts += 3; home.l++; }
    else { home.d++; away.d++; home.pts++; away.pts++; }
  }

  return groups;
}

function buildResults(matches) {
  return matches
    .filter((m) => m.score && m.score.ft)
    .map((m) => ({
      group: (m.group || "").replace(/^Group\s*/i, "").trim(),
      date: m.date || "",
      home: { flag: flagFor(m.team1), name: m.team1 },
      score: `${m.score.ft[0]}–${m.score.ft[1]}`,
      away: { flag: flagFor(m.team2), name: m.team2 },
      venue: m.ground || m.venue || m.stadium || "",
    }));
}

function buildScorers(matches) {
  const tally = {}; // "name|team" -> { goals, assists, gp:Set }
  for (const m of matches) {
    if (!m.score || !m.score.ft) continue;
    const teamsByGoalsKey = [
      ["goals1", m.team1],
      ["goals2", m.team2],
    ];
    for (const [key, team] of teamsByGoalsKey) {
      const scorers = m[key] || [];
      for (const g of scorers) {
        const name = g.name;
        if (!name) continue;
        const k = `${name}|${team}`;
        if (!tally[k]) tally[k] = { name, nat: team, goals: 0, assists: 0, matches: new Set() };
        tally[k].goals++;
        tally[k].matches.add(m.date + m.team1 + m.team2);
      }
    }
  }
  const list = Object.values(tally).map((s) => ({
    flag: flagFor(s.nat),
    name: s.name,
    nat: s.nat,
    pos: "FW", // openfootball doesn't carry position; default, dashboard still renders fine
    goals: s.goals,
    assists: s.assists,
    gp: s.matches.size,
  }));
  list.sort((a, b) => (b.goals !== a.goals ? b.goals - a.goals : b.assists - a.assists));
  let rank = 1;
  list.forEach((s, i) => {
    if (i > 0 && (s.goals !== list[i - 1].goals || s.assists !== list[i - 1].assists)) rank = i + 1;
    s.rank = rank;
  });
  return list;
}

async function main() {
  console.log(`Fetching ${MATCHES_URL} ...`);
  const wc = await httpsGetJson(MATCHES_URL);
  console.log(`Fetching ${GROUPS_URL} ...`);
  const wcGroups = await httpsGetJson(GROUPS_URL);

  const matches = wc.matches || [];
  const rawGroups = wcGroups.groups || [];

  const groups = buildGroups(rawGroups, matches);
  const results = buildResults(matches).slice(-40); // keep payload light, most recent 40
  const scorers = buildScorers(matches);

  const totalGoals = results.reduce((sum, m) => {
    const [h, a] = m.score.split("–").map(Number);
    return sum + h + a;
  }, 0);

  const output = {
    lastUpdated: new Date().toISOString(),
    source: "openfootball/worldcup.json (public domain)",
    totalGoals,
    matchesPlayed: results.length,
    groups,
    results,
    scorers,
  };

  const outPath = path.join(__dirname, "..", "data", "standings.json");
  fs.mkdirSync(path.dirname(outPath), { recursive: true });
  fs.writeFileSync(outPath, JSON.stringify(output, null, 2));
  console.log(`Wrote ${outPath}`);
  console.log(`Groups: ${groups.length}, Results: ${results.length}, Scorers: ${scorers.length}`);
}

main().catch((err) => {
  console.error("Fetch failed:", err.message);
  process.exit(1);
});
