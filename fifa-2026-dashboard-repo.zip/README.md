# FIFA World Cup 2026 Live Dashboard 🏆

A self-updating dashboard for the FIFA World Cup 2026 (USA · Canada · Mexico),
covering group standings, results, top scorers, and squads.

**Live demo (after enabling GitHub Pages):**
`https://<your-username>.github.io/<repo-name>/`

## How it stays up to date

```
GitHub Actions (daily, 06:00 UTC)
        │
        ▼
scripts/fetch-data.js  ──fetches──▶  openfootball/worldcup.json (public domain, no key)
        │
        ▼
data/standings.json  (committed back to the repo)
        │
        ▼
index.html  ──fetch()'s──▶  data/standings.json  (on page load + Refresh click)
```

- **`scripts/fetch-data.js`** — Node script with zero dependencies. Pulls match
  results and group lists from the [openfootball/worldcup.json](https://github.com/openfootball/worldcup.json)
  public-domain dataset, computes standings (W/D/L/GF/GA/Pts) and a top-scorers
  table, and writes everything to `data/standings.json`.
- **`.github/workflows/refresh-data.yml`** — Runs the script once a day via
  GitHub Actions (cron) and commits `data/standings.json` if it changed. You
  can also trigger it manually from the **Actions** tab → *Refresh World Cup
  Data* → **Run workflow**.
- **`index.html`** — The dashboard itself. On load (and whenever you click the
  **🌐 Refresh** button) it fetches `data/standings.json` and re-renders the
  Standings, Results, and Top Scorers tabs. Squad lists are static (rosters
  don't change daily).

No API keys, secrets, or backend server required — everything runs on GitHub's
free tier.

## Setup

1. **Upload these files** to a new GitHub repository (keep the folder structure).
2. **Settings → Pages** → Source: *Deploy from a branch* → `main` / `(root)` → Save.
3. **Settings → Actions → General** → under "Workflow permissions" select
   **Read and write permissions** (required so the daily job can commit
   `data/standings.json` back to the repo).
4. Your site goes live at `https://<username>.github.io/<repo>/` within ~1 minute.
5. (Optional) Go to the **Actions** tab and manually run *Refresh World Cup
   Data* once to populate `data/standings.json` with the very latest results
   immediately, instead of waiting for the next scheduled run.

## Updating manually

```bash
node scripts/fetch-data.js   # regenerates data/standings.json locally
git add data/standings.json
git commit -m "manual data refresh"
git push
```

## Notes & limitations

- The upstream openfootball dataset is updated roughly once a day by its
  maintainer, so this is **near-live**, not second-by-second live scoring.
- Player **positions** aren't included in the source data, so the scorers
  table defaults everyone to `FW` — feel free to enrich this in
  `scripts/fetch-data.js` if you have a positions lookup.
- Upcoming fixture kickoff times aren't part of the parsed feed (only
  completed results are surfaced); the Fixtures tab will show a placeholder
  message until matches are played, or you can extend the script to surface
  `matches[]` entries with no `score.ft` yet.
- Squads are hardcoded for ~12 marquee nations as a starting point — extend
  the `SQUADS` array in `index.html` for full 48-team coverage.

## Credits

- Match & group data: [openfootball/worldcup.json](https://github.com/openfootball/worldcup.json) (public domain, CC0)
